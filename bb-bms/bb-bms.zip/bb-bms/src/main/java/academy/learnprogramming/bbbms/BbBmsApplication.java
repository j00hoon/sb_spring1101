package academy.learnprogramming.bbbms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BbBmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BbBmsApplication.class, args);
	}

}
