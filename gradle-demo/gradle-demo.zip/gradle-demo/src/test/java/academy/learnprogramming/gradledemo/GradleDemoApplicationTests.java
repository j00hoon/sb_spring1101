package academy.learnprogramming.gradledemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradleDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
